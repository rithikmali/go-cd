// lskjgdmsfsld.mkfs
// dfjlsdm
// sjldkmv
// kjnlkm
// kbjnlmk

/*sdkjlnvkm
jhkbjnk;ml
hgjkm
gvjhbkjl
ghkbjnlkm
jgvhbkjnl
jhbkjnl*/
package main

import "fmt"

func main()
{
    // var b, c int = 1, 2,12,12
     for i := 1; i < 5; i++ 
     {
         var z = "lex"
         const l,m,pqr,lsts,asd= 1,3,4,3,1
		 for j := 1; j < 5; j++ 
		{
			fmt.Println("I'm a Nested for")	
			abad:=10
			par:="Par"		
		}						//Grammer Accepted
         
    }

    switch i {
    case 1:
        fmt.Println("one")
    case 2:
        fmt.Println("two")
    case 3:
        fmt.Println("three")
    }

    switch t := ooo.(type) {
    case bool:
        fmt.Println("I'm a bool")
		switch i {
		case 1:
			fmt.Println("one")
		case 2:
			fmt.Println("two")
		case 3:
			fmt.Println("three")
		}
    case int:
        fmt.Println("I'm an int")
    default:
        fmt.Printf("Don't know type")
    }											//Grammar Accepted
}