// lskjgdmsfsld.mkfs
// dfjlsdm
// sjldkmv
// kjnlkm
// kbjnlmk

/*sdkjlnvkm
jhkbjnk;ml
hgjkm
gvjhbkjl
ghkbjnlkm
jgvhbkjnl
jhbkjnl*/

package main

import "fmt"

func main() {
    maya:="Aravind"
    maya="Hello"
    var a,b, pqr int = 1,10, 1
	b=30*2/92+10
    b=20
	aravind:=100
	aravind=20
    for pqr=1;pqr<10;pqr++
    {
		a = 4 + 1
		pqr=3+1
	}
    i:=2
    cas:="Cas0"
    switch i
    {
    case 1:
        cas="Cas1"
    case 2:
        cas="Cas2"
    case 3:
        cas="Cas3"
    case 4:
        cas="Cas4"
    case 5:
        cas="Cas5"
    case 6:
        cas="Cas6"
    }
}